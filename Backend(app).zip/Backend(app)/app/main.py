from fastapi import FastAPI
from app.database import engine
from app import models
from app.routers import users

app = FastAPI(title="Job Platform API")

models.Base.metadata.create_all(bind=engine)

app.include_router(users.router)

@app.get("/")
def root():
    return {"status": "API running"}
