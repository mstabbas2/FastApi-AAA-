from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app import models, schemas
from app.utils import hash_password, verify_password, create_access_token, verify_access_token

router = APIRouter(prefix="/users", tags=["Users"])

# DB dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# =========================
# Register User
# =========================
@router.post("/register")
def register(user: schemas.UserRegister, db: Session = Depends(get_db)):

    # Check email, phone, username uniqueness
    if db.query(models.User).filter(models.User.email == user.email).first():
        raise HTTPException(status_code=400, detail="Email already exists")
    
    if db.query(models.User).filter(models.User.phone == user.phone).first():
        raise HTTPException(status_code=400, detail="Phone number already exists")

    if db.query(models.User).filter(models.User.username == user.username).first():
        raise HTTPException(status_code=400, detail="Username already exists")

    # Create new user
    new_user = models.User(
        username=user.username,
        name=user.name,
        email=user.email,
        password=hash_password(user.password),
        role=user.role,
        phone=user.phone,
        profile_picture=user.profile_picture
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {"message": "User registered successfully", "id": new_user.id}


# =========================
# Login User
# =========================
@router.post("/login")
def login(user: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if not db_user or not verify_password(user.password, db_user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Create JWT token
    token_data = {"user_id": db_user.id, "role": db_user.role}
    token = create_access_token(token_data)

    return {
        "message": "Login successful",
        "access_token": token,
        "token_type": "bearer",
        "id": db_user.id,
        "username": db_user.username,
        "role": db_user.role
    }


# =========================
# Helper: get current user
# =========================
def get_current_user(authorization: str = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing token")
    
    try:
        token = authorization.split(" ")[1]  # Bearer <token>
    except IndexError:
        raise HTTPException(status_code=401, detail="Invalid token format")

    payload = verify_access_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    return payload


# =========================
# Protected Route: Profile
# =========================
@router.get("/profile")
def profile(current_user: dict = Depends(get_current_user)):
    return {
        "user_id": current_user["user_id"],
        "role": current_user["role"]
    }
