from passlib.hash import sha256_crypt
from datetime import datetime, timedelta
from jose import JWTError, jwt



# سرّ التطبيق (خلي secret طويل وآمن)
SECRET_KEY = "mysecretkey1234567890"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60  # مدة صلاحية الـ token

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_access_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload  # payload يحتوي على البيانات اللي حطيتها وقت الإنشاء
    except JWTError:
        return None




def hash_password(password: str):
    return sha256_crypt.hash(password)

def verify_password(password: str, hashed: str):
    return sha256_crypt.verify(password, hashed)
